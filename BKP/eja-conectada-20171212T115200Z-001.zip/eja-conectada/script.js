function openWin() {
    window.open("mapa.html");
}